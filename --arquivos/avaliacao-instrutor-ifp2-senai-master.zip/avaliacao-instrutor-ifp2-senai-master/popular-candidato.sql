/*
-- Query: 
-- Date: 2022-10-11 14:01
*/
INSERT INTO `` (`id`,`email`,`nome_candidato`,`rg`,`vaga_candidato`) VALUES (1,'josedascouves@senai.com.br','José das Couves','12.345.678-00',1);
