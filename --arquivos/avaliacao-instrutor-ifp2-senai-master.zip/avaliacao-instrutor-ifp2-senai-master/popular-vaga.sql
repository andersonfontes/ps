/*
-- Query: 
-- Date: 2022-10-11 14:01
*/
INSERT INTO `` (`codigo`,`data`,`descricao`,`nome`,`salario`) VALUES (1,'31/12/2022 00:00:00','Vaga para Instrutor de Tecnologia em que o perfil profissional deve incluir conhecimentos em banco de dados e desenvolvimento de sistemas em Java.','Instrutor de Tecnologia',2500.00);
